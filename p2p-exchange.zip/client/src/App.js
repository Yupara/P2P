import React, { useState } from 'react';

function App() {
  const [amount, setAmount] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:5000/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount }),
      });
      const data = await response.json();
      alert(data.message || 'Ордер создан!');
    } catch (error) {
      alert('Ошибка: ' + error.message);
    }
  };

  return (
    <div className="bg-gray-900 min-h-screen p-8 text-white">
      <form onSubmit={handleSubmit} className="max-w-md mx-auto">
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="Сумма USDT"
          className="w-full p-2 mb-4 bg-gray-800 rounded"
        />
        <button
          type="submit"
          className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 rounded"
        >
          Купить
        </button>
      </form>
    </div>
  );
}

export default App;
