# P2P Exchange

This is a simple P2P exchange project with a React client and an Express/MongoDB server.

## Client

- Navigate to the `client` folder and run `npm install`, then `npm start` to launch the React app.

## Server

- Navigate to the `server` folder and run `npm install`, then `node server.js` to launch the API server.

Both parts should be running concurrently for the full application to work.