const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

// Подключение к MongoDB
mongoose.connect('mongodb://localhost:27017/p2p_exchange', { 
  useNewUrlParser: true, 
  useUnifiedTopology: true 
});

// Модель ордера
const OrderSchema = new mongoose.Schema({
  amount: Number,
  status: { type: String, default: 'pending' }
});
const Order = mongoose.model('Order', OrderSchema);

const app = express();
app.use(cors());
app.use(express.json());

// Создание ордера
app.post('/api/orders', async (req, res) => {
  try {
    const { amount } = req.body;
    const newOrder = new Order({ amount });
    await newOrder.save();
    res.status(201).json({ message: 'Ордер создан!', order: newOrder });
  } catch (error) {
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

app.listen(5000, () => console.log('Сервер запущен на http://localhost:5000'));
